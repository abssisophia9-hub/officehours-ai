# Deliverable 1 — Final Technical Report

**OfficeHours AI** Capstone Final Technical Report for Al Akhawayn University (SSE, EGR 4402).

## Primary files

| File | Purpose |
| --- | --- |
| [`OfficeHours_AI_Final_Technical_Report.docx`](./OfficeHours_AI_Final_Technical_Report.docx) | **Submit this** — AUI-branded Capstone-structured Word report (logo, Times New Roman, §§1–11, EN/FR abstracts, APA refs, appendices, embedded figures) |
| [`OfficeHours_AI_Final_Technical_Report.md`](./OfficeHours_AI_Final_Technical_Report.md) | Editable Markdown twin (same structure and claims) |
| [`SOURCES.md`](./SOURCES.md) | Provenance, evidence tip SHAs, honesty notes |

## Supporting folders

- `figures/` — architecture diagrams, product screenshots (`product-*.png`), mid-report SVGs
- `appendix/` — MEASURED JSON/MD eval exports from `reports/final_report/`
- `assets/` — AUI logo + Capstone Word template reference

## Evidence baseline

- `origin/main` tip: `db8de9b` (merge of PR #147)
- Freeze tag `final-nov-16` → `6264d95` (PR #146 lineage; parent of #147)
- Help Coach described as **retrieval + templates + optional style LogReg** (not LLM)
- Prefer MEASURED claims; lab metrics carry honesty caveats

## Capstone template sections covered

Cover · Conduct · Student Statement · Acknowledgements · Contents · List of Figures/Tables · Abstract EN · Résumé FR · §§1–11 · References (APA) · Appendix A Codex · Appendix B Eval · Appendix C Screenshots

## Reconciliation note

`PROJECT_FACTS.md` was not available at build time. If Sophia later drops it into the Project store, reconcile numbers/claims against that file and bump this deliverable.
